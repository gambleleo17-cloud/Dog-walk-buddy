DOG WALK BUDDY — FRESH RESET VERSION

The app starts with a completely fresh set of saved data.
No reset button is included.

All app features remain, including:
- Leo / Dylan / Leo + Dylan booking
- 30 minutes = £5
- 45 minutes = £10
- 1 hour = £15
- Profiles
- Availability
- Ratings
- Earnings
